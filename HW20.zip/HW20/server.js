import express from "express";
import cookieParser from "cookie-parser";
import { v4 } from "uuid";
import path from "node:path";

const app = express();
const PORT = 4000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Serve static files
app.use("/static", express.static("public"));
app.use(express.static(path.resolve("public")));

// Simulated database
const userList = [
    {
        id: "1",
        name: "Xamidulloh",
        email: "xamidullo@gmail.com",
        password: "qwer12345",
    },
];

// index html
app.get("/", (req, res, next) => {
    try {
        const filePath = path.join(import.meta.dirname, "public", "index.html");
        res.sendFile(filePath);
    } catch (error) {
        next(error);
    }
});

// resgister page
app.get("/register", (req, res, next) => {
    try {
        const filePath = path.join(import.meta.dirname, "public", "register.html");
        res.sendFile(filePath);
    } catch (error) {
        next(error);
    }
});

// register
app.post("/register", (req, res, next) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            throw { status: 400, message: "Please provide all required fields" };
        }

        if (userList.find((user) => user.email === email)) {
            throw { status: 400, message: "User already exists" };
        }

        const newUser = { id: v4(), name, email, password };
        userList.push(newUser);

        res.send(`
			<h1>Registration Successful</h1>
			<p>Thank you for registering with us, ${name}</p>
			<a href="/login">Login</a>
		`);
    } catch (error) {
        next(error);
    }
});

// login page
app.get("/login", (req, res, next) => {
    try {
        const filePath = path.join(import.meta.dirname, "public", "login.html");
        res.sendFile(filePath);
    } catch (error) {
        next(error);
    }
});

// login
app.post("/login", (req, res, next) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            throw { status: 400, message: "Please provide email and password" };
        }

        const user = userList.find((u) => u.email === email);
        if (!user) {
            throw { status: 404, message: "User not found" };
        }

        if (user.password !== password) {
            throw { status: 400, message: "Invalid password" };
        }

        // id in cookie
        res.cookie("userId", user.id, { httpOnly: true });
        res.redirect("/profile");
    } catch (error) {
        next(error);
    }
});

// profile
app.get("/profile", (req, res, next) => {
    try {
        const filePath = path.join(import.meta.dirname, "public", "profile.html");
        res.sendFile(filePath);
    } catch (error) {
        next(error);
    }
});

// API2fetch profile
app.get("/api/profile", (req, res, next) => {
    try {
        const userId = req.cookies.userId;

        if (!userId) {
            throw { status: 401, message: "Unauthorized" };
        }

        const user = userList.find((u) => u.id === userId);
        if (!user) {
            throw { status: 404, message: "User not found" };
        }

        res.json({ name: user.name, email: user.email });
    } catch (error) {
        next(error);
    }
});

// logout
app.get("/logout", (req, res, next) => {
    try {
        res.clearCookie("userId");
        res.redirect("/login");
    } catch (error) {
        next(error);
    }
});

//error middleware
app.use((error, req, res, next) => {
    const status = error.status || 500;
    const message = error.message || "Something went wrong";
    res.status(status).send(message);
});

//server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
