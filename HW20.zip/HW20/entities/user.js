export class User {
    constructor(firstName, lastName, email, password, phoneNumber, address) {
        this.first_name = firstName;
        this.last_name = lastName;
        this.email = email;
        this.password = password;
        this.phone_number = phoneNumber;
        this.address = address;
    }
}